#!/bin/bash

/mnt/sdb/wr-core/build-xilinx-zynq/tmp/sysroots/x86_64-linux/usr/bin/dtc -I dts -O dtb -o dtb ./pulsar_spi_i2c.dts

